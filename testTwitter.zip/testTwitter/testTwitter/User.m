//
//  User.m
//  testTwitter
//
//  Created by Андрей Решетников on 06.09.16.
//  Copyright © 2016 Андрей Решетников. All rights reserved.
//

#import "User.h"

@implementation User

- (id)copyWithZone:(NSZone*)zone
{
    User* user = [[[self class] allocWithZone:zone] init];
    user.idStr = self.idStr;
    user.name = self.name;
    user.imageURL = self.imageURL;
    return user;
}

- (BOOL)isEqual:(id)object
{
    if (self == object) return YES;
    if (![object isKindOfClass:[User class]]) return NO;
    return [self.idStr isEqualToString:[object idStr]];
}

- (NSUInteger)hash
{
    return [self.idStr hash];
}

- (instancetype)initWithJSON:(NSDictionary*)dictionary
{
    if (self = [super init]) {
        self.idStr = [dictionary[@"id_str"] copy];
        self.name = [dictionary[@"name"] copy];
        self.imageURL = [NSURL URLWithString:dictionary[@"profile_image_url"]];
    }
    return self;
}

@end
