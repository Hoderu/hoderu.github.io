//
//  TweetTableViewController.m
//  testTwitter
//
//  Created by Андрей Решетников on 06.09.16.
//  Copyright © 2016 Андрей Решетников. All rights reserved.
//

#import "TweetTableViewController.h"
#import "TwitterHTTPClient.h"
#import "TweetsDataController.h"
#import "TweetCell.h"
#import "Tweet.h"

static CGFloat const timerIntervalConst = 0.5;
static NSString* const imageTime = @"\u231B";

@interface TweetTableViewController () <GetTweetsDelegate>

@property (nonatomic, strong) TweetsDataController* dataController;
@property (nonatomic, weak) UILabel* timerLabel;
@property (nonatomic, weak) NSTimer* timer;

@end

@implementation TweetTableViewController

- (void)awakeFromNib
{
    [super awakeFromNib];
    
    self.dataController = [[TweetsDataController alloc] init];
    self.dataController.delegate = self;
    
    UILabel* timer = [[UILabel alloc] init];
    timer.text = [self timerLabelText];
    [timer sizeToFit];
    
    UIBarButtonItem* timerItem = [[UIBarButtonItem alloc] initWithCustomView:timer];
    self.navigationItem.leftBarButtonItem = timerItem;
    self.timerLabel = timer;
}

- (NSString*)timerLabelText
{
    if ([self.dataController runningTask]) {
        return imageTime;
    } else {
        NSTimeInterval interval = [self.dataController timerLastTime];
        return [NSString stringWithFormat:@"%@%lu", imageTime, (unsigned long)interval];
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)timeGo
{
    self.timerLabel.text = [self timerLabelText];
    [self.timerLabel sizeToFit];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.tableView reloadData];
    NSTimer* myTimer = [NSTimer timerWithTimeInterval:timerIntervalConst target:self selector:@selector(timeGo) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:myTimer forMode:NSRunLoopCommonModes];
    self.timer = myTimer;
    [self.dataController getTweets];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    [self.dataController stopGettingTweets];
    [self.timer invalidate];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataController.tweets.count;
}

- (UITableViewCell*)tableView:(UITableView*)tableView cellForRowAtIndexPath:(NSIndexPath*)indexPath
{
    TweetCell* cell = [tableView dequeueReusableCellWithIdentifier:@"TweetCell" forIndexPath:indexPath];
    Tweet* tweet = self.dataController.tweets[indexPath.row];
    
    [cell configureWithTweet:tweet image:nil completion:nil];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    Tweet* tweet = self.dataController.tweets[indexPath.row];
    return [TweetCell getCellHeight:tweet width:CGRectGetWidth(tableView.bounds) height:CGRectGetHeight(tableView.bounds)];
}

#pragma mark - delegate

- (void)tweetsDidChanged:(TweetsDataController*)controller
{
    [self.tableView reloadData];
}

@end
