//
//  Tweet.m
//  testTwitter
//
//  Created by Андрей Решетников on 06.09.16.
//  Copyright © 2016 Андрей Решетников. All rights reserved.
//

#import "Tweet.h"
#import "User.h"

@implementation Tweet

- (id)copyWithZone:(NSZone*)zone
{
    Tweet* tweet = [[[self class] allocWithZone:zone] init];
    tweet.idStr = self.idStr;
    tweet.text = self.text;
    tweet.user = self.user;
    return tweet;
}

- (instancetype)initWithJSON:(NSDictionary*)dictionary
{
    if (self = [super init]) {
        self.idStr = [dictionary[@"id_str"] copy];
        self.text = [dictionary[@"text"] copy];
        self.user = [[User alloc] initWithJSON:dictionary[@"user"]];
    }
    return self;
}

@end
