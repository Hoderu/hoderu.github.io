//
//  TweetsDataController.m
//  testTwitter
//
//  Created by Андрей Решетников on 06.09.16.
//  Copyright © 2016 Андрей Решетников. All rights reserved.
//

#import "TweetsDataController.h"
#import "FMDBBase.h"
#import "Tweet.h"
#import "User.h"
#import "SDWebImageManager.h"
#import "SDWebImagePrefetcher.h"

static CGFloat const timerConst = 60;

@interface TweetsDataController ()

@property (nonatomic, weak) NSURLSessionTask* task;
@property (nonatomic, readwrite, copy) NSArray* tweets;
@property (nonatomic, weak) NSTimer* downTimer;
@property (nonatomic, assign) BOOL viewControllerDisappearFlag;
@property (nonatomic, strong) FMDBBase* base;

@end

@implementation TweetsDataController

- (void)getTweets
{
    self.base = [FMDBBase sharedInstance];
    self.viewControllerDisappearFlag = YES;
    __weak typeof(self) weakSelf = self;
    [self.base getCachedTweets:^(NSArray *tweets, NSError *error) {
        if (tweets) {
            weakSelf.tweets = tweets;
        }
        //Решил сделать так:
        //Загружаем закешированные твиты и
        //сразу выполняем запрос на новые твиты
        [weakSelf reloadTweets];
    }];
}

- (void)stopGettingTweets
{
    self.viewControllerDisappearFlag = NO;
    [self.task cancel];
    [self.downTimer invalidate];
}

- (void)reloadTweets
{
    [self.downTimer invalidate];
    
    self.twitterClient = [[TwitterHTTPClient alloc] init];
    __weak typeof(self) weakSelf = self;
    self.task = [self.twitterClient searchTweets:^(NSArray* tweets, NSError* error) {
        if (tweets) {
            
            NSSortDescriptor* sortDescriptor;
            sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"idStr" ascending:NO];
            NSArray* sortDescriptors = [NSArray arrayWithObject:sortDescriptor];
            tweets = [tweets sortedArrayUsingDescriptors:sortDescriptors];
            
            weakSelf.tweets = tweets;
            [weakSelf.delegate tweetsDidChanged:self];
            [self.base writeTweetsToBase:tweets completion:nil];
        }
        
        NSMutableSet* imageURLSet = [NSMutableSet set];
        for (Tweet* tweet in tweets) {
            NSURL* url = tweet.user.imageURL;
            if (![[SDWebImageManager sharedManager] cachedImageExistsForURL:url]) {
                [imageURLSet addObject:url];
            }
        }
        [[SDWebImagePrefetcher sharedImagePrefetcher] prefetchURLs:[imageURLSet allObjects]];
        
        if (weakSelf.viewControllerDisappearFlag) {
            weakSelf.downTimer = [NSTimer scheduledTimerWithTimeInterval:timerConst target:self selector:@selector(getTweets) userInfo:nil repeats:NO];
        }
    }];
}

- (NSTimeInterval)timerLastTime
{
    return MAX(0.0, [self.downTimer.fireDate timeIntervalSinceNow]);
}

- (BOOL)runningTask
{
    return !!self.task;
}

@end
