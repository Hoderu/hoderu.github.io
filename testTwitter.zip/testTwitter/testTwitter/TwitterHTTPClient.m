//
//  TwitterHTTPClient.m
//  testTwitter
//
//  Created by Андрей Решетников on 06.09.16.
//  Copyright © 2016 Андрей Решетников. All rights reserved.
//

#import "TwitterHTTPClient.h"
#import "GCOAuth.h"
#import "Tweet.h"

static NSString* const TwitterHTTPClientConsumerKeyAPIKey = @"M9QIyoz983yTHpWb0PWHcyUCk";
static NSString* const TwitterHTTPClientConsumerSecretAPISecret = @"S2YZsGWGC6dc4LNVFYD9D6rbyzqETWMrU0H6NFaFNSiO1tVTM5";
static NSString* const TwitterHTTPClientAccessToken = @"1470124477-4wQOmVPveTW3WlcPX7JB40aUI3bitBpN1xqFBWr";
static NSString* const TwitterHTTPClientAccessTokenSecret = @"4OfTUyHyHGSiCIa3nuVSwvoiKJXwBkKyfrtr3tQWzMQ0y";

static NSString* const TwitterSearchPath = @"/1.1/search/tweets.json";

@implementation TwitterHTTPClient

- (NSURLSessionTask*)searchTweets:(TweetsCompletionBlock)competionBlock
{
    NSDictionary* parameters = @{ @"q" : @"mail",
                                  @"result_type" : @"recent",
                                  @"lang" : @"en" };
    
    NSURLRequest* request = [GCOAuth URLRequestForPath:TwitterSearchPath
                                         GETParameters:parameters
                                                scheme:@"https"
                                                  host:@"api.twitter.com"
                                           consumerKey:TwitterHTTPClientConsumerKeyAPIKey
                                        consumerSecret:TwitterHTTPClientConsumerSecretAPISecret
                                           accessToken:TwitterHTTPClientAccessToken
                                           tokenSecret:TwitterHTTPClientAccessTokenSecret];
    
    NSURLSessionDataTask* task = [[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData* data, NSURLResponse* response, NSError* taskError) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (taskError) {
                if (competionBlock) {
                    competionBlock(nil, taskError);
                }
                return;
            }
            
            NSError* error;
            id JSONDictionary = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
            if (error) {
                if (competionBlock) {
                    competionBlock(nil, error);
                }
                return;
            }
            
            NSHTTPURLResponse* HTTPResponse = (id)response;
            if ([HTTPResponse statusCode] != 200) {
                NSError* errorWithSomeCode = [NSError errorWithDomain:@"Error with code"
                                                      code:[HTTPResponse statusCode]
                                                      userInfo:nil];
                if (competionBlock) {
                    competionBlock(nil, errorWithSomeCode);
                }
            }
            
            NSMutableArray* tweetsArray = [NSMutableArray array];
            NSArray* tweetsJSON = JSONDictionary[@"statuses"];
            for(NSDictionary* statusJSON in tweetsJSON) {
                NSDictionary* newStatusJSON = [[NSDictionary alloc] init];
                newStatusJSON = statusJSON[@"retweeted_status"] ? statusJSON[@"retweeted_status"] : statusJSON;
                [tweetsArray addObject:[[Tweet alloc] initWithJSON:newStatusJSON]];
            }
            if (competionBlock) {
                competionBlock(tweetsArray, nil);
            }
        });
    }];
    
    [task resume];
    return task;
}

@end
