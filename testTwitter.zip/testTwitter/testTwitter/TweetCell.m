//
//  TweetCell.m
//  testTwitter
//
//  Created by Андрей Решетников on 06.09.16.
//  Copyright © 2016 Андрей Решетников. All rights reserved.
//

#import "TweetCell.h"
#import "User.h"
#import "UIImageView+WebCache.h"

static CGFloat const ConstAvatarWidth = 48;

@interface TweetCell ()

@property (weak, nonatomic) IBOutlet UIImageView* avatar;
@property (weak, nonatomic) IBOutlet UILabel* userNameLabel;
@property (weak, nonatomic) IBOutlet UILabel* tweetText;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint* avatarWidth;

@end

@implementation TweetCell

- (void)configureWithTweet:(Tweet*)tweet image:(UIImage*)image completion:(ImageBlock)completion
{
    self.userNameLabel.text = tweet.user.name;
    self.tweetText.text = tweet.text;
    
    NSUserDefaults* userDefaults = [NSUserDefaults standardUserDefaults];
    BOOL isOn = [userDefaults boolForKey:@"TwitterSaveAvatarsKey"];
    self.avatarWidth.constant = isOn ? ConstAvatarWidth : 0;
    
    [self.avatar sd_setImageWithURL:tweet.user.imageURL];
}

- (void)prepareForReuse
{
    [super prepareForReuse];
    self.userNameLabel.text = @"";
    self.tweetText.text = @"";
    self.avatar.image = nil;
    [self.avatar sd_cancelCurrentImageLoad];
}

+ (CGFloat)getCellHeight:(Tweet*)tweet width:(CGFloat)width height:(CGFloat)height
{
    CGRect textLabelFrame = CGRectMake(8 + 48 + 8, 8 + 16 + 4, width - 64.0 - 8.0, height - 28 - 8);
    NSMutableParagraphStyle* paragraphStyle = [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
    paragraphStyle.lineBreakMode = NSLineBreakByWordWrapping;
    NSDictionary* textAttributes = @{ NSFontAttributeName : [UIFont systemFontOfSize:13],
                                      NSParagraphStyleAttributeName : paragraphStyle };
    CGRect boundingRect = [tweet.text boundingRectWithSize:textLabelFrame.size options:NSStringDrawingUsesLineFragmentOrigin attributes:textAttributes context:nil];
    CGFloat resultHeight = (MAX(64, 8 + 16 + 4 + CGRectGetHeight(boundingRect) + 8) + 2);
    return resultHeight;
}

@end
