//
//  TweetsDataController.h
//  testTwitter
//
//  Created by Андрей Решетников on 06.09.16.
//  Copyright © 2016 Андрей Решетников. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TwitterHTTPClient.h"
@import UIKit;

@class TweetsDataController;

@protocol GetTweetsDelegate <NSObject>

- (void)tweetsDidChanged:(TweetsDataController*)controller;

@end

@interface TweetsDataController : NSObject

@property (nonatomic, strong) TwitterHTTPClient* twitterClient;
@property (nonatomic, readonly, copy) NSArray* tweets;
@property (nonatomic, weak) id<GetTweetsDelegate> delegate;

- (void)getTweets;
- (void)stopGettingTweets;
- (NSTimeInterval)timerLastTime;
- (BOOL)runningTask;

@end
